package com.demo.service;

import com.demo.bean.Product;

public interface ProductService {
    boolean addProduct(Product p);

    void showAll();

    boolean deleteProduct();

    void sortByPrice();

    boolean updateQuantity();

    boolean updatePrice();

    boolean updateDiscount();

}