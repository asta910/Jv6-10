package com.demo.service;

public interface UserService {

    void showAllProducts();

    boolean addToBucket();

    void sortByPrice();

    void sortByName();

    boolean removeFromBucket();

    boolean changeUserName();

    void showMyBucket();

    boolean changePassword();
}
