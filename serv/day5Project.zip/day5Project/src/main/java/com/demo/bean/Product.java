package com.demo.bean;

public class Product {
    private int id;
    private String pName;
    private int quantity;
    private int price;
    private double discount;
    private String description;
    private double total_price;

    public Product(String pName, int quantity, int price, double discount, String description) {
        this.pName = pName;
        this.quantity = quantity;
        this.price = price;
        this.discount = discount;
        this.description = description;
    }
    public Product(int id,String pName, int quantity, int price, double discount, String description,double total_price) {
        this.id = id;
        this.pName = pName;
        this.quantity = quantity;
        this.price = price;
        this.discount = discount;
        this.description = description;
        this.total_price=total_price;
    }

    public Product() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }

    @Override
    public String toString() {
        return "id=" + id +
                ", price=" + price +
                ", quantity=" + quantity +
                ", pName='" + pName + '\'' +
                ", discount=" + discount +
                ", description='" + description + '\'' +
                "total_price=" + total_price ;
    }
}