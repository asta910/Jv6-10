package com.demo.service;

import com.demo.bean.Product;
import com.demo.dao.DaoOperationImpl;
import com.demo.dao.DaoOperations;

import java.util.List;
import java.util.Scanner;

public class ProductServiceImpl implements ProductService{
    static Scanner sc;
    DaoOperations daoOperations;
    public ProductServiceImpl(){
        daoOperations = new DaoOperationImpl();
    }

    static{
        sc = new Scanner(System.in);
    }
//add
    public boolean addProduct(Product p) {
        Product product = new Product(p.getpName(),p.getQuantity(),p.getPrice(),p.getDiscount(),p.getDescription());
        return daoOperations.addProduct(product);
    }

//show
    public List<Product> showAll() {
		return daoOperations.showAll();
    }
//delete
    public boolean deleteProduct(int id) {
        return daoOperations.deleteItem(id);
    }


    public void sortByPrice() {
        daoOperations.sortByPrice();
    }


    public boolean updateQuantity() {
        System.out.print("Enter product id who's quantity you want to update: ");
        int pid = sc.nextInt();
        System.out.print("Enter new quantity : ");
        int qunt = sc.nextInt();
        return daoOperations.updateQuantity(pid,qunt);
    }

    public boolean updatePrice() {
        System.out.print("Enter product id who's price you want to update: ");
        int pid = sc.nextInt();
        System.out.print("Enter new price : ");
        int qunt = sc.nextInt();
        return daoOperations.updatePrice(pid,qunt);
    }


    public boolean updateDiscount() {
        System.out.print("Enter product id who's discount you want to update: ");
        int pid = sc.nextInt();
        System.out.print("Enter new discount : ");
        double qunt = sc.nextInt();
        qunt = qunt*0.01;
        return daoOperations.updateDiscount(pid,qunt);
    }
}