package com.demo.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.demo.bean.Person;
import com.demo.dao.DaoOperationImpl;
import com.demo.dao.DaoOperations;

public class UserRegistrationImpl implements UserRegistration {
    DaoOperations daoOperations;

    public UserRegistrationImpl() {
        daoOperations = new DaoOperationImpl();
    }

    public boolean addNewUser (String uName, String pass, String dob) {
        LocalDate date;
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            date = LocalDate.parse(dob, formatter);
            Person person = new Person(uName, pass, date, "user");
            return daoOperations.addNewUser (person);
        } catch (DateTimeParseException e) {
            e.printStackTrace();
        }
        return false;
    }
}