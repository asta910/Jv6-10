package com.demo.service;

import java.util.List;

import com.demo.bean.Product;

public interface ProductService {
    boolean addProduct(Product p);

    List<Product> showAll();

    boolean deleteProduct(int i);

    void sortByPrice();

    boolean updateQuantity();

    boolean updatePrice();

    boolean updateDiscount();

}