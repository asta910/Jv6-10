package com.demo.dao;

import com.demo.bean.Person;
import com.demo.bean.Product;

import java.sql.SQLException;
import java.util.List;

public interface DaoOperations {
    Person findPerson(String n,String p) throws SQLException;

    boolean addProduct(Product product);

    List<Product> showAll();

    boolean deleteItem(int id);

    void sortByPrice();

    boolean updateQuantity(int pid, int qunt);

    boolean updatePrice(int pid, int qunt);

    boolean updateDiscount(int pid, double qunt);

    boolean addNewUser(Person p);

    boolean addToBucket(String userName, int pid);

    void sortByName();

    boolean removeFromBucket(String name, int id);

    void showBucket(String user, String pass);

    boolean changeUserName(String user, String pass, String newUser);

    boolean changePassword(String user, String pass, String newUser);
}

// insert into productJdbc(pName,quantity,price,discount,description) values('Maggi',100,20,0.01,'kinda good');