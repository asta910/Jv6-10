package com.demo.service;

public interface UserRegistration {

    boolean addNewUser(String uName, String pass,String date);
}
