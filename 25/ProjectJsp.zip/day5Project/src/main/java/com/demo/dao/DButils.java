package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DButils {
    private static Connection connection;

    static {
        try {
            //mysql --host=192.168.10.127 --port=3306 --user=dac99 --password=welcome
        	DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            String url = "jdbc:mysql://192.168.10.127:3306/dac99";
            connection = DriverManager.getConnection(url, "dac99", "welcome");
        } catch (SQLException e) {
            System.out.println("Initial connection creation failed: " + e.getMessage());
        }
    }

    public static Connection getConnectionMy() {
        try {
            if (connection == null || connection.isClosed()) {
            	DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
                String url = "jdbc:mysql://192.168.10.127:3306/dac99";
                connection = DriverManager.getConnection(url, "dac99", "welcome");
                System.out.println("Connection" + connection);
            }
        } catch (SQLException e) {
            System.out.println("Connection creation failed: " + e.getMessage());
        }
        return connection;
    }

    public static void closeConnectionMy() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException e) {
                System.out.println("Failed to close connection: " + e.getMessage());
            }
        }
    }
}