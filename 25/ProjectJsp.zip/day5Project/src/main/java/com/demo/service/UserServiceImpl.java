package com.demo.service;

import com.demo.dao.DButils;
import com.demo.dao.DaoOperationImpl;
import com.demo.dao.DaoOperations;

import java.sql.SQLOutput;
import java.util.Scanner;

public class UserServiceImpl implements UserService{
    DaoOperations daoOperations;
    Scanner sc = new Scanner(System.in);
    public UserServiceImpl(){
        daoOperations = new DaoOperationImpl();
    }

    public void showAllProducts() {
        daoOperations.showAll();
    }

    //    create table bucket(username VARCHAR(30), productId INT, FOREIGN KEY (username) REFERENCES login(username))
    public boolean addToBucket() {
        System.out.println("Enter user name");
        String userName = sc.next();
        System.out.println("Enter product id");
        int pid = sc.nextInt();
        return daoOperations.addToBucket(userName,pid);
    }


    public void sortByPrice() {
        daoOperations.sortByPrice();
    }


    public void sortByName() {
        daoOperations.sortByName();
    }


    public boolean removeFromBucket() {
        System.out.print("Enter you username : ");
        String name = sc.next();
        System.out.print("Enter product id you want to remove from bucket : ");
        int id = sc.nextInt();
        return daoOperations.removeFromBucket(name,id);
    }


    public boolean changeUserName(){
        System.out.println("Enter your username: ");
        String user = sc.next();
        System.out.println("Enter your password: ");
        String pass = sc.next();
        System.out.println("Enter your new username : ");
        String newUser= sc.next();
        return daoOperations.changeUserName(user,pass,newUser);
    }


    public void showMyBucket(){
        System.out.print("Enter your userName : ");
        String user = sc.next();
        System.out.print("Enter your password : ");
        String pass = sc.next();
        daoOperations.showBucket(user,pass);
    }


    public boolean changePassword(){
        System.out.println("Enter your username: ");
        String user = sc.next();
        System.out.println("Enter your password: ");
        String pass = sc.next();
        System.out.println("Enter your new password : ");
        String newPass= sc.next();
        return daoOperations.changePassword(user,pass,newPass);
    }


}
